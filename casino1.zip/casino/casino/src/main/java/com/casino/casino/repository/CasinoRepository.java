package com.casino.casino.repository;

import com.casino.casino.entity.Casino;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CasinoRepository extends JpaRepository<Casino,Integer> {
    Casino findById(int id);
}
