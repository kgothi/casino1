package com.casino.casino;

import jakarta.persistence.Entity;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CasinoApplication {


	public static void main(String[] args) {
		SpringApplication.run(CasinoApplication.class, args);
	}

}
