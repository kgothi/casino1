package com.casino.casino.controller;


import com.casino.casino.entity.Casino;
import com.casino.casino.repository.CasinoRepository;
import org.apache.catalina.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping(path = "/casino")
public class CasinoController {
    @Autowired
    CasinoRepository casinoRepository;

    @PostMapping(value = "/balance")
    public @ResponseBody String addBalance(@RequestParam double balance){
        Casino casino = new Casino();
        casino.setBalance(balance);
        casinoRepository.save(casino);
        return "Blance created";
    }

    @GetMapping(path = "/player/{id}")
    public @ResponseBody String getById(Integer id){
        Casino casino = new Casino();
        casino.getId();
        casinoRepository.findAll();
        return "id";
    }

    @GetMapping(path = "/player/")
    public @ResponseBody Iterable <Casino> getAllUsers() {
        return casinoRepository.findAll();
    }
}
